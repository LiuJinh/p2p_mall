<?php

namespace app\index\controller;

use think\Db;
use think\Request;

class Follow
{

	public function follow(){
		$trans = Request::Instance()->get();

		$session1 = $trans['open_id'];

		$session2 = $trans['follow_id'];

		$cSessionInfo1 = Db::table('cSessionInfo')->where('skey',$session1)->find();
//		$cSessionInfo2 = Db::table('cSessionInfo')->where('skey',$session2)->find();

		$open_id1 = $cSessionInfo1['open_id'];
//		$open_id2 = $cSessionInfo2['opem_id'];

		if(Db::table('follower')->where('session_id',$open_id1)->where('follow_id',$session2)->count()){
			return "exist";
		}
		Db::table('follower')->insert(['session_id'=>$open_id1,'follow_id'=>$session2]);
		return "ok";
	}

	
	public function getMyFol(){
		$user = Request::Instance()->get();

		$session = $user['open_id'];
		$cSessionInfo = Db::table('cSessionInfo')->where('skey',$session)->find();
		$open_id = $cSessionInfo['open_id'];
		$res = Db::table('follower')->where('session_id',$open_id)->alias(['follower'=>'a','User'=>'b'])->join('User','b.open_id=a.follow_id')->select();
		return $res;

	}

	public function delete(){
		$user = Request::Instance()->get();
		$session_id1 = $user['open_id'];

		$session_id2 = $user['follow_id'];

		$cSessionInfo1 = Db::table('cSessionInfo')->where('skey',$session_id1)->find();
//		$cSessionInfo2 = Db::table('cSessionInfo')->where('skey',$session_id2)->find();

		$open_id1 = $cSessionInfo1['open_id'];
//		$open_id2 = $cSessionInfo2['open_id'];

		$res = Db::table('follower')->where('session_id',$open_id1)->where('follow_id',$session_id2)->delete();
	}

	public function isExist(){
		$user = Request::Instance()->get();
                $session_id1 = $user['open_id'];

                $session_id2 = $user['follow_id'];

                $cSessionInfo1 = Db::table('cSessionInfo')->where('skey',$session_id1)->find();
//                $cSessionInfo2 = Db::table('cSessionInfo')->where('skey',$session_id2)->find();

                $open_id1 = $cSessionInfo1['open_id'];
  //              $open_id2 = $cSessionInfo2['open_id'];
//
		if(Db::table('follower')->where('session_id',$open_id1)->where('follow_id',$session_id2)->count()){
			return "exist";
		}
		
		return "no";
	}

}
