<?php
namespace app\index\controller;

use think\Db;
use think\Request;
class UserConnect
{
	public function connect(){

                $user = Request::Instance()->get();
                $session_id = $user['session_id'];
                $cSessionInfo = Db::table('cSessionInfo')->where('skey',$session_id)->find();
                $open_id = $cSessionInfo['open_id'];

                Db::execute("delete from User where open_id='".$open_id."'");


	}





}

