<?php

namespace app\index\controller;

use think\Db;
use think\Request;

class UploadPhoto{
	public function test(){

		mkdirs(iconv("UTF-8", "GBK", $path),0777,true);	
			
	}


	public function upload(){

//		if($_FILES["file"]["error"]<1){
//			$wenjianjia = "/photos";
	
//			$name1 = "file";
			
//			if(!is_dir($wenjianjia)){
//				if(!mkdir("/photos",0700,true)){
//					return "fail make";	
//				}	
			//	mkdir("/photos",0700);	
			
//			}


//			$wenjianjiatime = $wenjianjia.date('y-m-d',time());
////			if(!fire_exists($wenjianjiatime)){
///				mkdir($wenjianjiatime);
//			}

//			$namee = data('h-i-s')."-".$_FILES[$name1]["name"];
//
//			$name = $wenjianjia.data('y-m-d',time())."/".$namee;

//			$result = move_uploaded_file($_FILES[$name1]["tmp_name"],"1234.png");
	
//			$tc_information=$name;
//			$tc_information=json_encode($tc_information,JSON_UNESCAPED_SLASHES);
//			return "这里是Phpp";





//		}
//		else{
//			$tc_information="图片上传出错了";
//			$tc_information=json_encode($tc_information);
//			return $tc_information;
//		}

		$imgname = $_POST["imgname"];
		$existed = $_POST["existed"];
//		return $existed;
//
//		if($existed){
//			unlink('/webdata/photos/'+$imgname);
//		}
		
		$tmp = $_FILES['file']['tmp_name'];
   		$filepath = '/webdata/photos/';
//	return exec('whoami');
		if(move_uploaded_file($tmp,$filepath.$imgname)){
	        	return "上传成功";
		}else{
			return "上传失败";
		}


	}
	



} 
