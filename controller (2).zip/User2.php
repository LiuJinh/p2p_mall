<?php

namespace app\index\controller;

use think\Db;
use think\Request;
class User
{
	public function test()
	{
		dump('haha');
		//$res = Db::query("select * from User;");
		//dump($res);
	}
	public function userInsert()
	{
		$user = Request::Instance()->get();
		Db::table('User')->insert([
			'open_id'	=> $user["open_id"],
			'name'		=> $user['name'],
			'signature'	=> $user['signature'],
			'sex'		=> $user['sex'],
			'school'	=> $user['school'],
			'major'		=> $user['major'],
			'grade'		=> $user['grade'],
			'campus'	=> $user['campus']
		]);
	}

	public function userUpdate()
	{
		$user = Request::Instance()->get();
 		Db::table('User')->where('open_id', $user['open_id'])->update([
			'name'		=> $user['name'],
			'signature'	=> $user['signature'],
			'sex'		=> $user['sex'],
			'school'	=> $user['school'],
			'major'		=> $user['major'],
			'grade'		=> $user['grade'],
			'campus'	=> $user['campus']
 		]);
		/*Db::execute("update User set name='".$user['name']."'',signature='".$user['signature']."',sex='".$user['sex']."',school='".$user['school']."',major='".$user['major']."',grade='".$user['grade']."',campus='".$user['campus']."' where open_id=".$user['open_id']);*/
	}

	public function userDelete()
	{
		//Db::table('User')->delete($open_id);
		$user = Request::Instance()->get();
		$open_id = $user['open_id'];
		Db::execute("delete from User where open_id='".$open_id."'");
	}

	public function userFind()
	{
		$user = Request::Instance()->get();
		$session_id = $user['session_id'];
		return $session_id;
		$sessionInfo = Db::table('cSessionInfo')->where('skey',$session_id)->find();
		$open_id = $sessionInfo['open_id'];
		return $open_id;
		$res = Db::table('User')->where('open_id',$open_id)->find();
		//return $res;
	}
}
