<?php

namespace app\index\controller;

use think\Db;
use think\Request;

class BookShelf
{
        public function test(){
                dump('helloshelf');

        }

	public function bookInsert()
        {
                $book = Request::Instance()->get();

		if(Db::table('Book')->where('book_id',$book["book_id"])->count()){
		

			Db::table('Book')->where('book_id',$book["book_id"])->delete();
		}
		
		$session_id = $book['open_id'];
		$cSessionInfo = Db::table('cSessionInfo')->where('skey',$session_id)->find();
		$open_id = $cSessionInfo['open_id'];
		
                Db::table('Book')->insert([
                        'book_id'       => $book["book_id"],
                        'book_name'     => $book['book_name'],
                        'abstract'      => $book['abstract'],
                        'price'         => $book['price'],
                        'tag'           => $book['tag'],
                        'image'         => $book['image'],
                        'grade'         => $book['grade'],
                        'date'          => date("Y-m-d"),
			'open_id'	=> $open_id,
                	'visible'	=> $book['visible']
		]);
		
		return "success";

        }

	public function bookOwn()
	{
		
		$user = Request::Instance()->get();
			
		$session_id = $user['open_id'];
	
		$cSessionInfo = Db::table('cSessionInfo')->where('skey',$session_id)->find();
		$open_id = $cSessionInfo['open_id'];		

		$res = Db::table('Book')->where('open_id',$open_id)->order('book_name')->select();


	
		return $res;
		
	

	}
	
	public function bookOwn1()
        {

                $user = Request::Instance()->get();

                $open_id = $user['open_id'];

//                $cSessionInfo = Db::table('cSessionInfo')->where('skey',$session_id)->find();
 //               $open_id = $cSessionInfo['open_id'];

                $res = Db::table('Book')->where('open_id',$open_id)->select();



                return $res;



        }




	public function bookFindById()
        {
                $user = Request::Instance()->get();

                $book_id = $user['book_id'];
		$res = Db::table('Book')->where('book_id',$book_id)->alias(['Book'=>'A','User'=>'B'])->join('User','A.open_id=B.open_id')->find();

//		$res1 = Db::table('cSessionInfo')->where('open_id',$res['open_id'])->select();

//		$res['session_id']=$res1;
		return $res;
	}


	public function bookDelete(){
		$book = Request::Instance()->get();
		$book_id = $book['book_id'];
		$res = Db::table('Book')->where('book_id',$book_id)->delete();

		return $res;
	
	}	
}
