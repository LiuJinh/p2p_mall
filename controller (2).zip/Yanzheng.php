<?php

namespace app\index\controller;

use think\Db;
use think\Request;
class Yanzheng
{
	
	public function GetAll(){
		$res = Db::table('yanZheng')->where('yanzheng_id',null)->select();
		return $res;
	
	}






	public function Apply()
	{
		$yanzheng = Request::Instance()->get();
		
		$session_id = $yanzheng["session_id"];
		if(Db::table('yanZheng')->where('session_id',$session_id)->count()){
			Db::table('yanZheng')->where('session_id',$session_id)->delete();
		}


		Db::table('yanZheng')->insert([
			'session_id'	=> $yanzheng["session_id"],
			'phone_number'  => $yanzheng["phone_number"],
			'email'		=> $yanzheng["email"]
		]);
		$res = "ok";
		return $res;
	}
	public function Audit()
	{
		$User = Request::Instance()->get();
		$session_id = $User['session_id'];
		$cSessionInfo = Db::table('cSessionInfo')->where('skey',$session_id)->select();
		$User = Db::table('User')->where('open_id',$cSessionInfo['open_id'])->select();
		if($User['authority'=='2'])
		{
			$res = Db::table('yanZheng')->select();
			return $res;
		}
		else{ return 0;}
	}
	public function giveId()
	{
		$User = Request::Instance()->get();
		$yanzheng_id = $User['yanzheng_id'];
		$session_id = $User["session_id"];
//		$cSessionInfo = Db::table('cSessionInfo')->where('skey',$session_id)->select();//获取cSessionInfo
//                $User = Db::table('User')->where('open_id',$cSessionInfo['open_id'])->select();
//		if($User['authority']=='2')//判断是否有管理员权限
//		{
			Db::table('yanZheng')->where('session_id',$session_id)->update([
				'yanzheng_id'	=> $yanzheng_id
			]);
			$res = 'success';
			return $res;
//		}
//		else{return 0;}
	}
	public function yanZheng()
	{
		$User = Request::Instance()->get();
                $yanzheng_id = $User['yanzheng_id'];//获取验证码
                $session_id = $User["session_id"];
		$cSessionInfo = Db::table('cSessionInfo')->where('skey',$session_id)->find();
		$yanzheng = Db::table('yanZheng')->where('session_id',$session_id)->find();
		//判断验证码是否正确
		if($yanzheng_id == $yanzheng['yanzheng_id'])
		{
			Db::table('User')->where('open_id',$cSessionInfo['open_id'])->update([
					'authority'    =>  '1',
					'phone_number' => $yanzheng["phone_number"],
					'email'	       => $yanzheng["email"]
				]);
			Db::table('yanZheng')->where('session_id',$session_id)->delete();
			return 1;

		}
		else return 0;
	}

	public function delete(){

		$User = Request::Instance()->get();
                $session_id = $User["session_id"];

		Db::table('yanZheng')->where('session_id',$session_id)->delete();

	
	
	}
} 
