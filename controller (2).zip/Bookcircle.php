<?php
namespace app\index\controller;
// +----------------------------------------------------------------------
// | @bookName	书名
// +----------------------------------------------------------------------
// | @image     书的图片链接
// +----------------------------------------------------------------------
// | @price     书的价格
// +----------------------------------------------------------------------
// | @tag       书的标签
// +----------------------------------------------------------------------
// | @bookId    书的编号
// +----------------------------------------------------------------------

use think\Db;
use think\Request;
class BookCircle
{
	// +----------------------------------------------------------------------
	// | 书圈
	// +----------------------------------------------------------------------
	
	

	public function allBooks(){
		$user = Request::Instance()->get();
		$all_acount = $user['all_acount'];
                $session_id = $user['open_id'];
                $cSessionInfo = Db::table('cSessionInfo')->where('skey',$session_id)->find();
                $open_id = $cSessionInfo['open_id'];

                $res = Db::table('Book')->select();
		$count = count($res);//统计数据集条数
		$count = (($count-1)-(($count-1)%10))/10;//可刷新的总次数
		
		if($all_acount <= $count)
		{
			if($all_acount == $count){
				$res_temp = array_slice($res,$all_acount*10,count($res)-$all_acount*10);
			}
			else{
				$res_temp = array_slice($res,$all_acount*10,10);
			}
		}
		else{
			//不可刷新
			$res_temp = null;
		}
		return $res_temp;

	}


	public function test()
	{
		dump('babaloveyou');
	}
	public function bookCircle_1()
	{

	//从数据库中获取bookName、image、price、tag、bookId
	$res = Db::query('select * from Book order by date');

	//返回给controller
	return $res;
	//return $res;
	}

	// +----------------------------------------------------------------------
	// | 书圈搜索
	// +----------------------------------------------------------------------
	public function bookCircle_s($openid,$keyword)
	{

	//$request = Request::instance();
	//$keyword = $request->only('keyword');


	//从数据库中获取用户的搜索记录
	$select_history = Db::query('select tag_history from Select_history where openId = ?',$openid);
	//在数据库中保存用户的搜索记录
	$select = $select.' '.$keyword;
	Db::execute('update Select_history set tag_history=? where open_Id=?',[$select,$openid]);
	//根据用户搜索的关键词，从数据库中找到相应bookName、image、price、tag
	$res = Db::query('select * from Book where bookName like ?%',$keyword);
	//返回这些数据给controller
	return $res;
	}

	// +----------------------------------------------------------------------
	// | 书圈搜索
	// +----------------------------------------------------------------------
	public function bookSearch()
	{
	//价格优先
	$booksearch = Request::Instance()->get();

	$keyword = $booksearch['keyword'];
	
	$tag = $booksearch['tag'];
	//tag模糊匹配对应变量转换
	for($i=0;$i<7;$i++)
	{
		if($tag[$i]=='0')
		{
			$tag[$i] = '_';
		}
		elseif($tag[$i]=='1')
		{
			$tag[$i] = '0';
		}
		else
		{
			return 0;
		}
	}
	$acount = $booksearch['acount'];//前端刷新的次数
	
	$res = Db::table('Book')->whereor('book_name', 'like', '%'.$keyword.'%')->whereor('book_name','like',$keyword.'%')->whereor('book_name',$keyword)->whereNotLike('tag', $tag)->select();
	//$res = Db::table('Book')->whereNotLike('tag',$tag)->select();
	//return $res;
	$count = count($res);//数据集条数

	$count = (($count-1)-(($count-1) % 10))/10;//可刷新的总次数

	

	if($acount <= $count)
	{
		if($acount == $count){
			$res_temp = array_slice($res,$acount*10,count($res)-$acount*10);
		}
		else{
			$res_temp = array_slice($res,$acount*10,10);
		}
		//可刷新
	}
	else
	{
		//不可刷新
		$res_temp = null;
	}

	return $res_temp;
	}

	// +----------------------------------------------------------------------
	// | 查看某本书的信息
	// +----------------------------------------------------------------------
	// | @bookName	书名
	// +----------------------------------------------------------------------
	// | @image     书的图片链接
	// +----------------------------------------------------------------------
	// | @price     书的价格
	// +----------------------------------------------------------------------
	// | @tag       书的标签
	// +----------------------------------------------------------------------
	// | @abstract	书的摘要
	// +----------------------------------------------------------------------
	// | @openId    持有者id
	// +----------------------------------------------------------------------
	// | @bookId    书的编号
	// +----------------------------------------------------------------------

	public function bookCircle_message()
	{
	$bookId = Request::Instance()->get();

	//根据bookId从数据库中搜索出某本书的所有上述信息
	$res = Db::query('select bookName,image,price,tag,abstract,openId from Book where bookId=?',$bookId);
	//返回给controller
	return $res;
	}
	public function bookCircle_push()
	{
	$book_mes = Request::instance()->get();
	$book_mes['date'] = getdate();
	/*Db::table('Book')->insert([
		'bookId' 	=> $book_mes['bookId'],
		'bookName'	=> $book_mes['bookName'],
		'abstract'	=> $book_mes['bookAbstract'],
		'price'		=> $book_mes['price'],
		'tag'		=> $book_mes['tag'],
		'grade'		=> $book_mes['grade'],
		'image'		=> $book_mes['image'],
		'date'		=> $book_mes['date']
		]);*/
	return $book_mes;
	
	}

}

?>
