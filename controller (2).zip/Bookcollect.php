<?php

namespace app\index\controller;

use think\Db;
use think\Request;

class BookCollect
{
        public function test(){
                dump('helloshelf');

        }



	public function collect(){
		$transaction = Request::Instance()->get();
	
		$session_id = $transaction['owner'];
                $book_id = $transaction['book_id'];
                $cSessionInfo = Db::table('cSessionInfo')->where('skey',$session_id)->find();
                $open_id = $cSessionInfo['open_id'];


                if(Db::table('Transactions')->where('book_id',$transaction['book_id'])->where('user_id',$open_id)->count()){

			return "exist";
                }

                $session_id = $transaction['owner'];
		$book_id = $transaction['book_id'];
                $cSessionInfo = Db::table('cSessionInfo')->where('skey',$session_id)->find();
                $open_id = $cSessionInfo['open_id'];

                Db::table('Transactions')->insert([
                        'book_id'       => $transaction["book_id"],
                        'user_id'       => $open_id
                ]);

                return "success";


	}

	public function getMyCol(){

		$user = Request::Instance()->get();
		$session_id = $user['open_id'];
           
                $cSessionInfo = Db::table('cSessionInfo')->where('skey',$session_id)->find();
                $open_id = $cSessionInfo['open_id'];


		$res = Db::table('Transactions')->where('user_id',$open_id)->alias(['Transactions'=>'a','Book'=>'b'])->join('Book','b.book_id=a.book_id')->select();

		return $res;
	}

	public function delete(){
		$user = Request::Instance()->get();
                $session_id = $user['session_id'];
		$book_id = $user['book_id'];
                $cSessionInfo = Db::table('cSessionInfo')->where('skey',$session_id)->find();
                $open_id = $cSessionInfo['open_id'];
		
		$res = Db::table('Transactions')->where('book_id',$book_id)->where('user_id',$open_id)->delete();
	}

	public function isExist(){
		$transaction = Request::Instance()->get();

                $session_id = $transaction['owner'];
                $book_id = $transaction['book_id'];
                $cSessionInfo = Db::table('cSessionInfo')->where('skey',$session_id)->find();
                $open_id = $cSessionInfo['open_id'];


                if(Db::table('Transactions')->where('book_id',$transaction['book_id'])->where('user_id',$open_id)->count()){

                        return "yes";
                }
		return "no";
		



	}

}
