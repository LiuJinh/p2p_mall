<?php

namespace app\index\controller;

use think\Request;
use think\Db;
include_once "wxBizDataCrypt.php";
class Login
{
	public function wx_login(){
		$appinfo = Db::table('cAppInfo')->select();//获取cAppInfo数据表的信息
		$appid = $appinfo[0]["appid"];
		$secret = $appinfo[0]["secret"];
		$login_duration = $appinfo[0]["login_duration"];
		$session_duration = $appinfo[0]["session_duration"];

		$user = Request::Instance()->get();//获取get方式的数据以及确定将要发送的数据
		$js_code = $user['code'];
		$wxUrl = "https://api.weixin.qq.com/sns/jscode2session?appid=".$appid."&secret=".$secret."&js_code=".$js_code."&grant_type=authorization_code";

		//初始化一个cURL会话
		$ch = curl_init();
		//设置会话选项
		curl_setopt($ch,CURLOPT_URL,$wxUrl);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
		curl_setopt($ch,CURLOPT_HEADER,0);
		//执行一个cURL会话并且获取相关回复
		$response = curl_exec($ch);
		//释放cURL句柄，关闭cURL会话
		curl_close($ch);

		//处理wx返回的数据	
		//$wx_user_data = $response;
		$wx_user_data = json_decode($response, true);//json格式
		$session_key = $wx_user_data["session_key"];
		$openid = $wx_user_data["openid"];
	
		/*
		//数字签名校验
		$signature = $_GET["signature"];
		$signature2 = sha1($user["rawData"].$session_key);
		if($signature != $signature2){
			echo '数据签名验证失败！';
			die;
		}

		//解密，获取敏感信息
		Vendor("PHP.wxBizDataCrypt");
		$encryptedData = $user["encryptedData"];
		$iv = $user["iv"];
		$pc = new \WXBizDataCrypt($appid, $session_key);
		$errCode = $pc->decryptData($encryptedData, $iv, $data);
		if ($errCode != 0) {
		    echo '解密数据失败！';die;
		}
		*/

		//返回3rd_session
		//先检查sSssionInfo表openid对应的sessionid是否失效
		$check = '1';
		$have_openid = '1';
		//1.是否有该openid
		$session_info = Db::table('cSessionInfo')->where('open_id',$openid)->find();
		//if there is not,$check = '0'
		if($session_info ==null){
		  $check ='0';
		  $have_openid = '0';
		  $screate_time = date("Y-m-d");//生成会话时间记录
		  $last_visit_time = $screate_time;//生成sessionid时间记录
		  if(!Session_start()){
			Session_start();	
			
			}
		  $third_session = session_id();

		/*查看数据库，如果有相同的session_id，则重新生成一个*/

		 //插入数据库
		  Db::table('cSessionInfo')->insert([
//			'id'	=>  1,
			'skey'  =>  $third_session,
			'screate_time' =>  $screate_time,
			'last_visit_time' => $last_visit_time,
			'open_id'  =>  $openid,
			'session_key'  => $session_key,
			'user_info'   =>  ''

			]);
		}
		else{
		//有记录，则调用原来的session_id
			$res =Db::table('cSessionInfo')->where('open_id',$openid)->find();
			
			return $res['skey'];
		  //$screate_time = $session_info["screate_time"];
		  //$last_visit_time = $session_info["last_visit_time"];
		}
		//if there is one,check the sessionid whether empired
		//获取本地时间$local_time
		//比较local_time和登录时间和sessionid最近产生的时间
		//if empired，重新生成3rd_session,$check = '0'
		if($check =='0'){
		
		if($have_openid == '0'){
		if(!Session_start());
		{
			Session_start();
		}
		$third_session = session_id();
		dump($have_openid);
			}
		$local_time = date("Y-m-d");//获取本地时间$local_time
		$last_visit_time = $local_time;
		
		/*
		$third_session = '';
		$fp = fopen("/dev/urandom", "r");//r:只读，b:二进制打开
		if($fp !== FALSE){
			
			$bytes = fread($fp, 128);
			//二进制转字符串
			
			$arr = explode(' ',$bytes);
			foreach($arr as $v){
				$i = base_convert($v,2,16);
				$v = pack("H".strlen(base_convert($v,2,16)),base_convert($v,2,16));
				dump($i);
			}
			fclose($fp);
		}
		//dump($third_session);
		return $bytes;*/

		//if失效了，重新产生3rd_session插入到cSessionInfo
		}	
		return $third_session;
	}

	public function wx_login_signature(){
                $userinfo = Request::Instance()->get();//获取get方式的数据以及确定将要发送的数据
                $signature = $userinfo['signature'];
		$rawData = $userinfo['rawData'];
		$session_id = $userinfo['session_id'];
		$cSessionInfo = Db::table('cSessionInfo')->where('skey',$session_id)->find();
		$session_key = $cSessionInfo['session_key'];

		//数字签名校验
                $signature2 = sha1($rawData.$session_key);
                if($signature != $signature2){
                        echo '数据签名验证失败！';
                        die;
		}
	}

	public function wx_login_test(){
                $appinfo = Db::table('cAppInfo')->select();//获取cAppInfo数据表的信息
                $appid = $appinfo[0]["appid"];
                $secret = $appinfo[0]["secret"];
                $login_duration = $appinfo[0]["login_duration"];
                $session_duration = $appinfo[0]["session_duration"];

                $user = Request::Instance()->get();//获取get方式的数据以及确定将要发送的数据
                $js_code = $user['code'];
                $wxUrl = "https://api.weixin.qq.com/sns/jscode2session?appid=".$appid."&secret=".$secret."&js_code=".$js_code."&grant_type=authorization_code";

                //初始化一个cURL会话
                $ch = curl_init();
                //设置会话选项
                curl_setopt($ch,CURLOPT_URL,$wxUrl);
                curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
                curl_setopt($ch,CURLOPT_HEADER,0);
                //执行一个cURL会话并且获取相关回复
                $response = curl_exec($ch);
                //释放cURL句柄，关闭cURL会话
                curl_close($ch);

		$wx_user_data = json_decode($response, true);//json格式
                $session_key = $wx_user_data["session_key"];
                $openid = $wx_user_data["openid"];

		/*
                //数字签名校验
                $signature = $_GET["signature"];
                $signature2 = sha1($user["rawData"].$session_key);
                if($signature != $signature2){
                        echo '数据签名验证失败！';
                        die;
                }
		*/

                //解密，获取敏感信息
                Vendor("PHP.wxBizDataCrypt");
                $encryptedData = $user["encryptedData"];
                $iv = $user["iv"];
                $pc = new \WXBizDataCrypt($appid, $session_key);
                $errCode = $pc->decryptData($encryptedData, $iv, $data);
                if ($errCode != 0) {
                    echo $errCode;die;
                }


		$check = '1';
                $have_openid = '1';
                //1.是否有该openid
                $session_info = Db::table('cSessionInfo')->where('open_id',$openid)->find();
                //if there is not,$check = '0'
                if($session_info ==null){
                  $check ='0';
                  $have_openid = '0';
                  $screate_time = date("Y-m-d");//生成会话时间记录
                  $last_visit_time = $screate_time;//生成sessionid时间记录
                  if(!Session_start()){
                        Session_start();

                }
                  $third_session = session_id();
		Db::table('cSessionInfo')->insert([
//                      'id'    =>  1,
                        'skey'  =>  $third_session,
                        'screate_time' =>  $screate_time,
                        'last_visit_time' => $last_visit_time,
                        'open_id'  =>  $openid,
                        'session_key'  => $session_key,
                        'user_info'   =>  ''

                ]);
                }
                else{
                //有记录，则调用原来的session_id
                        $res =Db::table('cSessionInfo')->where('open_id',$openid)->find();

                        return $res['skey'];
			$third_session = $session_info["skey"];
                  }
                //if there is one,check the sessionid whether empired
                //获取本地时间$local_time
                //比较local_time和登录时间和sessionid最近产生的时间
                //if empired，重新生成3rd_session,$check = '0'
                if($check =='0'){

                if($have_openid == '0'){
                if(!Session_start());
                {
                        Session_start();
                }
                $third_session = session_id();
                dump($have_openid);
                        }
                $local_time = date("Y-m-d");//获取本地时间$local_time
                $last_visit_time = $local_time;
}
                return $third_session;
        }

}
?>
